<?php echo Form::open(['route' => 'microposts.store']); ?>

    <div class="form-group">
        <?php echo Form::textarea('content', old('content'), ['class' => 'form-control', 'rows' => '2']); ?>

        <?php echo Form::submit('Post', ['class' => 'btn btn-primary btn-block']); ?>

    </div>
<?php echo Form::close(); ?>

<?php /**PATH /home/ec2-user/environment/microposts/resources/views/microposts/form.blade.php ENDPATH**/ ?>