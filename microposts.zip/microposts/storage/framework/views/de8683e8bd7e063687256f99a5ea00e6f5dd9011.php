<?php if(count($microposts) > 0): ?>
    <ul class="list-unstyled">
        <?php $__currentLoopData = $microposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $micropost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="media mb-3">
                
                <img class="mr-2 rounded" src="<?php echo e(Gravatar::get($micropost->user->email, ['size' => 50])); ?>" alt="">
                <div class="media-body">
                    <div>
                        
                        <?php echo link_to_route('users.show', $micropost->user->name, ['user' => $micropost->user->id]); ?>

                        <span class="text-muted">posted at <?php echo e($micropost->created_at); ?></span>
                    </div>
                    <div>
                        
                        <p class="mb-0"><?php echo nl2br(e($micropost->content)); ?></p>
                    </div>
                    <div>
                        <?php if(Auth::id() == $micropost->user_id): ?>
                            
                            <?php echo Form::open(['route' => ['microposts.destroy', $micropost->id], 'method' => 'delete']); ?>

                                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-sm']); ?>

                            <?php echo Form::close(); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    
    <?php echo e($microposts ->links()); ?>

<?php endif; ?>
<?php /**PATH /home/ec2-user/environment/microposts/resources/views/microposts/microposts.blade.php ENDPATH**/ ?>