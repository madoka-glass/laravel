<?php $__env->startSection('content'); ?>
    <?php if(Auth::check()): ?>
        <div class="row">
            <aside class="col-sm-4">
                
                <?php echo $__env->make('users.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </aside>
            <div class="col-sm-8">
                
                <?php echo $__env->make('microposts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <?php echo $__env->make('microposts.microposts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    <?php else: ?>
        <div class="center jumbotron">
            <div class="text-center">
                <h1>Welcome to the Microposts</h1>
                
                <?php echo link_to_route('signup.get', 'Sign up now!', [], ['class' => 'btn btn-lg btn-primary']); ?>

            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ec2-user/environment/microposts/resources/views/welcome.blade.php ENDPATH**/ ?>