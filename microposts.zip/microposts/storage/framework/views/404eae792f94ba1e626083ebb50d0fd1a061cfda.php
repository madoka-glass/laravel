<div class="card">
    <div class="card-header">
        <h3 class="card-title"><?php echo e($user->name); ?></h3>
    </div>
    <div class="card-body">
        
        <img class="rounded img-fluid" src="<?php echo e(Gravatar::get($user->email, ['size' => 500])); ?>" alt="">
    </div>
</div>

<?php echo $__env->make('user_follow.follow_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ec2-user/environment/microposts/resources/views/users/card.blade.php ENDPATH**/ ?>