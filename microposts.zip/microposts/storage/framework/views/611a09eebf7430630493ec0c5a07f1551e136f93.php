<ul class="nav nav-tabs nav-justified mb-3">
    
    <li class="nav-item">
        <a href="<?php echo e(route('users.show', ['user' => $user->id])); ?>" class="nav-link <?php echo e(Request::routeIs('users.show') ? 'active' : ''); ?>">
            TimeLine
            <span class="badge badge-secondary"><?php echo e($user->microposts_count); ?></span>
        </a>
    </li>
    
    <li class="nav-item">
        <a href="<?php echo e(route('users.followings', ['id' => $user->id])); ?>" class="nav-link <?php echo e(Request::routeIs('users.followings') ? 'active' : ''); ?>">
            Followings
            <span class="badge badge-secondary"><?php echo e($user->followings_count); ?></span>
        </a>
    </li>
    
    <li class="nav-item">
        <a href="<?php echo e(route('users.followers', ['id' => $user->id])); ?>" class="nav-link <?php echo e(Request::routeIs('users.followers') ? 'active' : ''); ?>">
            Followers
            <span class="badge badge-secondary"><?php echo e($user->followers_count); ?></span>
        </a>
    </li>
</ul>
<?php /**PATH /home/ec2-user/environment/microposts/resources/views/users/navtabs.blade.php ENDPATH**/ ?>