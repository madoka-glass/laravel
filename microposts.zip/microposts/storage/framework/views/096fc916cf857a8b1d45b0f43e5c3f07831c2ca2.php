<?php if(count($users) > 0): ?>
    <ul class="list-unstyled">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="media">
                
                <img class="mr-2 rounded" src="<?php echo e(Gravatar::get($user->email, ['size' => 50])); ?>" alt="">
                <div class="media-body">
                    <div>
                        <?php echo e($user->name); ?>

                    </div>
                    <div>
                        
                        <p><?php echo link_to_route('users.show', 'View profile', ['user' => $user->id]); ?></p>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    
    <?php echo e($users->links()); ?>

<?php endif; ?>
<?php /**PATH /home/ec2-user/environment/microposts/resources/views/users/users.blade.php ENDPATH**/ ?>