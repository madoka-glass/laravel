<?php if(Auth::id() != $user->id): ?>
    <?php if(Auth::user()->is_following($user->id)): ?>
        
        <?php echo Form::open(['route' => ['user.unfollow', $user->id], 'method' => 'delete']); ?>

            <?php echo Form::submit('Unfollow', ['class' => "btn btn-danger btn-block"]); ?>

        <?php echo Form::close(); ?>

    <?php else: ?>
        
        <?php echo Form::open(['route' => ['user.follow', $user->id]]); ?>

            <?php echo Form::submit('Follow', ['class' => "btn btn-primary btn-block"]); ?>

        <?php echo Form::close(); ?>

    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /home/ec2-user/environment/microposts/resources/views/user_follow/follow_button.blade.php ENDPATH**/ ?>